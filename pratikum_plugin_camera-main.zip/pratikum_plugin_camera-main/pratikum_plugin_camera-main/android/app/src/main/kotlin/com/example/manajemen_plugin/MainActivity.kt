package com.example.manajemen_plugin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
