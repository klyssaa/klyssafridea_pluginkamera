## NAMA : KLYSSA FRIDEA

## NIM : 362358302157

## KELAS : 2B TRPL

## PRATIKUM PLUGIN CAMERA

## HASILNYA:

## ![WhatsApp Image 2024-11-04 at 11 56 01_58b59e49](https://github.com/user-attachments/assets/af688236-f399-4ef1-be63-e0865c421004)

## 1.jelaskan maksud dari void async?

void: Digunakan untuk fungsi yang tidak mengembalikan nilai apapun
async: Menandakan fungsi berjalan asinkron (tidak mengganggu proses lainnya) dan memungkinkan penggunaan await untuk menunggu proses selesai

- 2.jelaskan fungsi dari anotasi immutable dan override?
- immutable merujuk pada objek atau variabel yang nilainya tidak bisa di ubah setelah di definisikan.
- override adalah konsep dalam pemrograman berorientasi objek yang memungkinkan subclass untuk mendefinisikan ulang metode yang sudah di denfinisikan di superclass
-
